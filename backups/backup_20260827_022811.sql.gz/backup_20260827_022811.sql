--
-- PostgreSQL database dump
--

\restrict kxfyqARQPERZzh13tXQvOmWNgdxiyvrSn24Jw6a6dpPYGPrCggc6648U0buizzg

-- Dumped from database version 15.19
-- Dumped by pg_dump version 15.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admins; Type: TABLE; Schema: public; Owner: voip_user
--

CREATE TABLE public.admins (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    date_creation timestamp without time zone NOT NULL
);


ALTER TABLE public.admins OWNER TO voip_user;

--
-- Name: admins_id_seq; Type: SEQUENCE; Schema: public; Owner: voip_user
--

CREATE SEQUENCE public.admins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admins_id_seq OWNER TO voip_user;

--
-- Name: admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: voip_user
--

ALTER SEQUENCE public.admins_id_seq OWNED BY public.admins.id;


--
-- Name: cdr; Type: TABLE; Schema: public; Owner: voip_user
--

CREATE TABLE public.cdr (
    id integer NOT NULL,
    utilisateur_id integer NOT NULL,
    date_appel timestamp without time zone NOT NULL,
    duree integer NOT NULL,
    destination character varying(50) NOT NULL,
    cout numeric(10,2) NOT NULL,
    statut character varying(20) NOT NULL,
    type_connexion character varying(20) NOT NULL
);


ALTER TABLE public.cdr OWNER TO voip_user;

--
-- Name: cdr_id_seq; Type: SEQUENCE; Schema: public; Owner: voip_user
--

CREATE SEQUENCE public.cdr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cdr_id_seq OWNER TO voip_user;

--
-- Name: cdr_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: voip_user
--

ALTER SEQUENCE public.cdr_id_seq OWNED BY public.cdr.id;


--
-- Name: rechargements; Type: TABLE; Schema: public; Owner: voip_user
--

CREATE TABLE public.rechargements (
    id integer NOT NULL,
    utilisateur_id integer NOT NULL,
    token_id integer NOT NULL,
    montant numeric(10,2) NOT NULL,
    date_rechargement timestamp without time zone NOT NULL
);


ALTER TABLE public.rechargements OWNER TO voip_user;

--
-- Name: rechargements_id_seq; Type: SEQUENCE; Schema: public; Owner: voip_user
--

CREATE SEQUENCE public.rechargements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rechargements_id_seq OWNER TO voip_user;

--
-- Name: rechargements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: voip_user
--

ALTER SEQUENCE public.rechargements_id_seq OWNED BY public.rechargements.id;


--
-- Name: services_ivr; Type: TABLE; Schema: public; Owner: voip_user
--

CREATE TABLE public.services_ivr (
    id integer NOT NULL,
    nom character varying(100) NOT NULL,
    code character varying(20) NOT NULL,
    type character varying(50) NOT NULL,
    destination character varying(100) NOT NULL,
    description character varying(255),
    actif boolean DEFAULT true,
    date_creation timestamp without time zone DEFAULT now()
);


ALTER TABLE public.services_ivr OWNER TO voip_user;

--
-- Name: services_ivr_id_seq; Type: SEQUENCE; Schema: public; Owner: voip_user
--

CREATE SEQUENCE public.services_ivr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.services_ivr_id_seq OWNER TO voip_user;

--
-- Name: services_ivr_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: voip_user
--

ALTER SEQUENCE public.services_ivr_id_seq OWNED BY public.services_ivr.id;


--
-- Name: tarifs; Type: TABLE; Schema: public; Owner: voip_user
--

CREATE TABLE public.tarifs (
    id integer NOT NULL,
    description character varying(100),
    montant_par_seconde numeric(10,2) NOT NULL,
    actif boolean NOT NULL
);


ALTER TABLE public.tarifs OWNER TO voip_user;

--
-- Name: tarifs_id_seq; Type: SEQUENCE; Schema: public; Owner: voip_user
--

CREATE SEQUENCE public.tarifs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tarifs_id_seq OWNER TO voip_user;

--
-- Name: tarifs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: voip_user
--

ALTER SEQUENCE public.tarifs_id_seq OWNED BY public.tarifs.id;


--
-- Name: tokens; Type: TABLE; Schema: public; Owner: voip_user
--

CREATE TABLE public.tokens (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    montant numeric(10,2) NOT NULL,
    statut character varying(20) NOT NULL,
    date_creation timestamp without time zone NOT NULL,
    date_utilisation timestamp without time zone
);


ALTER TABLE public.tokens OWNER TO voip_user;

--
-- Name: tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: voip_user
--

CREATE SEQUENCE public.tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tokens_id_seq OWNER TO voip_user;

--
-- Name: tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: voip_user
--

ALTER SEQUENCE public.tokens_id_seq OWNED BY public.tokens.id;


--
-- Name: utilisateurs; Type: TABLE; Schema: public; Owner: voip_user
--

CREATE TABLE public.utilisateurs (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    nom_complet character varying(100) NOT NULL,
    email character varying(100),
    solde numeric(10,2) NOT NULL,
    statut character varying(20) NOT NULL,
    sip_id character varying(10),
    date_creation timestamp without time zone NOT NULL,
    sip_secret character varying(64)
);


ALTER TABLE public.utilisateurs OWNER TO voip_user;

--
-- Name: utilisateurs_id_seq; Type: SEQUENCE; Schema: public; Owner: voip_user
--

CREATE SEQUENCE public.utilisateurs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.utilisateurs_id_seq OWNER TO voip_user;

--
-- Name: utilisateurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: voip_user
--

ALTER SEQUENCE public.utilisateurs_id_seq OWNED BY public.utilisateurs.id;


--
-- Name: admins id; Type: DEFAULT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.admins ALTER COLUMN id SET DEFAULT nextval('public.admins_id_seq'::regclass);


--
-- Name: cdr id; Type: DEFAULT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.cdr ALTER COLUMN id SET DEFAULT nextval('public.cdr_id_seq'::regclass);


--
-- Name: rechargements id; Type: DEFAULT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.rechargements ALTER COLUMN id SET DEFAULT nextval('public.rechargements_id_seq'::regclass);


--
-- Name: services_ivr id; Type: DEFAULT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.services_ivr ALTER COLUMN id SET DEFAULT nextval('public.services_ivr_id_seq'::regclass);


--
-- Name: tarifs id; Type: DEFAULT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.tarifs ALTER COLUMN id SET DEFAULT nextval('public.tarifs_id_seq'::regclass);


--
-- Name: tokens id; Type: DEFAULT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.tokens ALTER COLUMN id SET DEFAULT nextval('public.tokens_id_seq'::regclass);


--
-- Name: utilisateurs id; Type: DEFAULT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.utilisateurs ALTER COLUMN id SET DEFAULT nextval('public.utilisateurs_id_seq'::regclass);


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: voip_user
--

COPY public.admins (id, username, password_hash, date_creation) FROM stdin;
1	admin	$2b$12$J5jUOTAQi31CX2fhOnohKu7vt7i9iD.LpwBfl8KwB83X99eYaXGdG	2026-08-24 23:53:43.659745
\.


--
-- Data for Name: cdr; Type: TABLE DATA; Schema: public; Owner: voip_user
--

COPY public.cdr (id, utilisateur_id, date_appel, duree, destination, cout, statut, type_connexion) FROM stdin;
\.


--
-- Data for Name: rechargements; Type: TABLE DATA; Schema: public; Owner: voip_user
--

COPY public.rechargements (id, utilisateur_id, token_id, montant, date_rechargement) FROM stdin;
\.


--
-- Data for Name: services_ivr; Type: TABLE DATA; Schema: public; Owner: voip_user
--

COPY public.services_ivr (id, nom, code, type, destination, description, actif, date_creation) FROM stdin;
1	Service Commercial	1001#	queue	commercial_queue	File d attente commerciale	t	2026-08-26 22:19:24.489678
2	Support Technique	1002#	queue	support_queue	File d attente support	t	2026-08-26 22:21:52.20593
3	Comptabilite	1003#	dial	PJSIP/2001	Poste comptabilite	t	2026-08-26 22:22:05.066045
4	Conference	1004*	conf	1234	Salle de conference	t	2026-08-26 22:22:16.210295
\.


--
-- Data for Name: tarifs; Type: TABLE DATA; Schema: public; Owner: voip_user
--

COPY public.tarifs (id, description, montant_par_seconde, actif) FROM stdin;
1	Tarif par defaut	1.00	t
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: voip_user
--

COPY public.tokens (id, code, montant, statut, date_creation, date_utilisation) FROM stdin;
2	7BB70AC7DAA5E719	500.00	non_utilise	2026-08-26 17:15:13.388979	\N
1	6A470AE42B7B1F15	2000.00	utilise	2026-08-25 00:01:07.62514	2026-08-26 17:18:50.917892
3	0270302944306241	1000.00	utilise	2026-08-26 17:45:03.75395	2026-08-26 17:47:39.528243
\.


--
-- Data for Name: utilisateurs; Type: TABLE DATA; Schema: public; Owner: voip_user
--

COPY public.utilisateurs (id, username, password_hash, nom_complet, email, solde, statut, sip_id, date_creation, sip_secret) FROM stdin;
12	test_auto	$2b$12$70DNeRRICMcyE4asylXnS./K45Hr9wvdZZHFDLg321NWecJ973J2K	Test Auto	testauto@gmail.com	0.00	actif	2001	2026-08-26 21:47:21.867761	lQnbD1lCCWlU3sDU
\.


--
-- Name: admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: voip_user
--

SELECT pg_catalog.setval('public.admins_id_seq', 1, true);


--
-- Name: cdr_id_seq; Type: SEQUENCE SET; Schema: public; Owner: voip_user
--

SELECT pg_catalog.setval('public.cdr_id_seq', 41, true);


--
-- Name: rechargements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: voip_user
--

SELECT pg_catalog.setval('public.rechargements_id_seq', 2, true);


--
-- Name: services_ivr_id_seq; Type: SEQUENCE SET; Schema: public; Owner: voip_user
--

SELECT pg_catalog.setval('public.services_ivr_id_seq', 4, true);


--
-- Name: tarifs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: voip_user
--

SELECT pg_catalog.setval('public.tarifs_id_seq', 1, true);


--
-- Name: tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: voip_user
--

SELECT pg_catalog.setval('public.tokens_id_seq', 3, true);


--
-- Name: utilisateurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: voip_user
--

SELECT pg_catalog.setval('public.utilisateurs_id_seq', 13, true);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: admins admins_username_key; Type: CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_username_key UNIQUE (username);


--
-- Name: cdr cdr_pkey; Type: CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.cdr
    ADD CONSTRAINT cdr_pkey PRIMARY KEY (id);


--
-- Name: rechargements rechargements_pkey; Type: CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.rechargements
    ADD CONSTRAINT rechargements_pkey PRIMARY KEY (id);


--
-- Name: services_ivr services_ivr_code_key; Type: CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.services_ivr
    ADD CONSTRAINT services_ivr_code_key UNIQUE (code);


--
-- Name: services_ivr services_ivr_pkey; Type: CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.services_ivr
    ADD CONSTRAINT services_ivr_pkey PRIMARY KEY (id);


--
-- Name: tarifs tarifs_pkey; Type: CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.tarifs
    ADD CONSTRAINT tarifs_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_code_key; Type: CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_code_key UNIQUE (code);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: utilisateurs utilisateurs_email_key; Type: CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT utilisateurs_email_key UNIQUE (email);


--
-- Name: utilisateurs utilisateurs_pkey; Type: CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT utilisateurs_pkey PRIMARY KEY (id);


--
-- Name: utilisateurs utilisateurs_sip_id_key; Type: CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT utilisateurs_sip_id_key UNIQUE (sip_id);


--
-- Name: utilisateurs utilisateurs_username_key; Type: CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.utilisateurs
    ADD CONSTRAINT utilisateurs_username_key UNIQUE (username);


--
-- Name: ix_admins_id; Type: INDEX; Schema: public; Owner: voip_user
--

CREATE INDEX ix_admins_id ON public.admins USING btree (id);


--
-- Name: ix_cdr_id; Type: INDEX; Schema: public; Owner: voip_user
--

CREATE INDEX ix_cdr_id ON public.cdr USING btree (id);


--
-- Name: ix_rechargements_id; Type: INDEX; Schema: public; Owner: voip_user
--

CREATE INDEX ix_rechargements_id ON public.rechargements USING btree (id);


--
-- Name: ix_tarifs_id; Type: INDEX; Schema: public; Owner: voip_user
--

CREATE INDEX ix_tarifs_id ON public.tarifs USING btree (id);


--
-- Name: ix_tokens_id; Type: INDEX; Schema: public; Owner: voip_user
--

CREATE INDEX ix_tokens_id ON public.tokens USING btree (id);


--
-- Name: ix_utilisateurs_id; Type: INDEX; Schema: public; Owner: voip_user
--

CREATE INDEX ix_utilisateurs_id ON public.utilisateurs USING btree (id);


--
-- Name: cdr cdr_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.cdr
    ADD CONSTRAINT cdr_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- Name: rechargements rechargements_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.rechargements
    ADD CONSTRAINT rechargements_token_id_fkey FOREIGN KEY (token_id) REFERENCES public.tokens(id);


--
-- Name: rechargements rechargements_utilisateur_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: voip_user
--

ALTER TABLE ONLY public.rechargements
    ADD CONSTRAINT rechargements_utilisateur_id_fkey FOREIGN KEY (utilisateur_id) REFERENCES public.utilisateurs(id);


--
-- PostgreSQL database dump complete
--

\unrestrict kxfyqARQPERZzh13tXQvOmWNgdxiyvrSn24Jw6a6dpPYGPrCggc6648U0buizzg

